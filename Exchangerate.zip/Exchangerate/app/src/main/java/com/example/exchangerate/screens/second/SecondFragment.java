package com.example.exchangerate.screens.second;

import android.app.Activity;

public class SecondFragment extends Activity {
}
