package com.example.exchangerate.screens.start

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.exchangerate.data.repository.Repository
import com.example.exchangerate.model.cash.cash
import kotlinx.coroutines.launch
import retrofit2.Response

class StartViewModel: ViewModel() {

    var repo = Repository()
    var myMoneyList: MutableLiveData<Response<cash>> = MutableLiveData()

    fun getCashMoney() {
        viewModelScope.launch {
            myMoneyList.value = repo.getCash()
        }
    }
}