package com.example.exchangerate.data.repository

import com.example.exchangerate.data.api.RetrifitInstance
import com.example.exchangerate.model.cash.cash
import retrofit2.Response

class Repository {
    suspend fun getCash(): Response<cash> {
        return RetrifitInstance.api.getCashMoneys()
    }
}