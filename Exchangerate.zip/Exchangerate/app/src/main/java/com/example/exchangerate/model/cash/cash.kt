package com.example.exchangerate.model.cash

class cash : ArrayList<cashItem>()