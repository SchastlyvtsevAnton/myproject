package com.example.exchangerate.model.cash

data class cashItem(
    val base_ccy: String,
    val buy: String,
    val ccy: String,
    val sale: String
)