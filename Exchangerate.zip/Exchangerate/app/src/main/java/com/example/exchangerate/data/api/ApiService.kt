package com.example.exchangerate.data.api

import com.example.exchangerate.model.cash.cash
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET("p24api/pubinfo?json&exchange&coursid=5")
    suspend fun getCashMoneys(): Response<cash>
}